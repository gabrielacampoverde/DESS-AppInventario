var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705369689725.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-42fd667a-a210-491e-b69f-d67a7074e672" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="ReporteInv_2"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/42fd667a-a210-491e-b69f-d67a7074e672-1705369689725.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="430.0px" datasizeheight="100.0px" dataX="0.0" dataY="59.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b277bb93-79c5-4f6f-bb30-be9624543377.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext manualfit firer commentable non-processed" customid="Reporte de Inventario"   datasizewidth="268.0px" datasizeheight="38.0px" dataX="65.0" dataY="95.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Reporte de Inventario</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Centro de Responsabilidad"   datasizewidth="323.7px" datasizeheight="28.0px" dataX="53.2" dataY="209.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Centro de Responsabilidad</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="379.0px" datasizeheight="114.0px" datasizewidthpx="379.0" datasizeheightpx="114.0" dataX="25.5" dataY="268.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="00994 - E.P. Ing. de Sist"   datasizewidth="306.8px" datasizeheight="18.0px" dataX="42.5" dataY="286.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">00994 - E.P. Ing. de Sistemas - Direcci&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="Line 1"   datasizewidth="347.0px" datasizeheight="3.3px" dataX="42.0" dataY="313.4"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="346.00360107421875" height="3.249993324279785" viewBox="41.99818843603134 313.4470222160082 346.00360107421875 3.249993324279785" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-42fd6" d="M42.5 314.4470189377527 L387.5 315.6970189377527 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-42fd6" fill="#000000" fill-opacity="1.0" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="Plus"   datasizewidth="24.7px" datasizeheight="24.0px" dataX="42.5" dataY="333.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="24.730430603027344" height="23.980440139770508" viewBox="42.5 332.9999999999998 24.730430603027344 23.980440139770508" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-42fd6" d="M44.18214103600045 346.62129729533007 L53.183015987503964 346.62129729533007 L53.183015987503964 355.3493935158872 C53.183015987503964 356.2364656595221 53.93565098113054 356.98044061660744 54.86524028029623 356.98044061660744 C55.79482957946192 356.98044061660744 56.54746457308849 356.2364656595221 56.54746457308849 355.3493935158872 L56.54746457308849 346.62129729533007 L65.54837394807323 346.62129729533007 C66.46318676778415 346.62129729533007 67.23043012618973 345.8916491347889 67.23043012618973 344.9902517471452 C67.23043012618973 344.0888559120368 66.46318676778415 343.3590447352801 65.54837394807323 343.3590447352801 L56.54746457308849 343.3590447352801 L56.54746457308849 334.6311418053786 C56.54746457308849 333.7440223094144 55.79482957946192 332.9999999999998 54.86524028029623 332.9999999999998 C53.93565098113054 332.9999999999998 53.183015987503964 333.7440223094144 53.183015987503964 334.6311418053786 L53.183015987503964 343.3590447352801 L44.18214103600045 343.3590447352801 C43.26729299226223 343.3590447352801 42.5 344.0888559120368 42.5 344.9902517471452 C42.5 345.8916491347889 43.26729299226223 346.62129729533007 44.18214103600045 346.62129729533007 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-42fd6" fill="#099957" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer commentable non-processed" customid="Minus"   datasizewidth="20.7px" datasizeheight="13.0px" dataX="232.0" dataY="338.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="21.712848663330078" height="14.003900527954102" viewBox="231.99999999999997 337.98827052116377 21.712848663330078 14.003900527954102" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-42fd6" d="M233.89819183935194 351.49217009544356 L251.8147578005463 351.49217009544356 C252.5694835672386 351.49217009544356 253.21284961700437 348.58366569698404 253.21284961700437 344.99054521378935 C253.21284961700437 341.45452764328854 252.5694835672386 338.48827052116377 251.8147578005463 338.48827052116377 L233.89819183935194 338.48827052116377 C233.1681589728539 338.48827052116377 232.49999999999997 341.45452764328854 232.49999999999997 344.99054521378935 C232.49999999999997 348.58366569698404 233.1681589728539 351.49217009544356 233.89819183935194 351.49217009544356 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-42fd6" fill="#099957" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="Total: 18"   datasizewidth="62.3px" datasizeheight="18.0px" dataX="79.2" dataY="336.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Total: 18</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="Faltan inv.: 0"   datasizewidth="91.6px" datasizeheight="18.0px" dataX="267.5" dataY="336.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">Faltan inv.: 0</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="379.0px" datasizeheight="114.0px" datasizewidthpx="379.0" datasizeheightpx="114.0" dataX="25.5" dataY="403.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext autofit firer ie-background commentable non-processed" customid="00994 - E.P. Ing. de Sist"   datasizewidth="311.3px" datasizeheight="18.0px" dataX="42.5" dataY="421.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">00994 - E.P. Ing. de Sistemas - Secretaria</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_4" class="path firer commentable non-processed" customid="Line 1"   datasizewidth="347.0px" datasizeheight="3.3px" dataX="42.0" dataY="448.4"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="346.00360107421875" height="3.249993324279785" viewBox="41.99818843603134 448.4470222160082 346.00360107421875 3.249993324279785" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_4-42fd6" d="M42.5 449.4470189377527 L387.5 450.6970189377527 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_4-42fd6" fill="#000000" fill-opacity="1.0" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_5" class="path firer commentable non-processed" customid="Plus"   datasizewidth="24.7px" datasizeheight="24.0px" dataX="42.5" dataY="468.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="24.730430603027344" height="23.980440139770508" viewBox="42.5 467.9999999999998 24.730430603027344 23.980440139770508" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_5-42fd6" d="M44.18214103600045 481.62129729533007 L53.183015987503964 481.62129729533007 L53.183015987503964 490.3493935158872 C53.183015987503964 491.2364656595221 53.93565098113054 491.98044061660744 54.86524028029623 491.98044061660744 C55.79482957946192 491.98044061660744 56.54746457308849 491.2364656595221 56.54746457308849 490.3493935158872 L56.54746457308849 481.62129729533007 L65.54837394807323 481.62129729533007 C66.46318676778415 481.62129729533007 67.23043012618973 480.8916491347889 67.23043012618973 479.9902517471452 C67.23043012618973 479.0888559120368 66.46318676778415 478.3590447352801 65.54837394807323 478.3590447352801 L56.54746457308849 478.3590447352801 L56.54746457308849 469.6311418053786 C56.54746457308849 468.7440223094144 55.79482957946192 467.9999999999998 54.86524028029623 467.9999999999998 C53.93565098113054 467.9999999999998 53.183015987503964 468.7440223094144 53.183015987503964 469.6311418053786 L53.183015987503964 478.3590447352801 L44.18214103600045 478.3590447352801 C43.26729299226223 478.3590447352801 42.5 479.0888559120368 42.5 479.9902517471452 C42.5 480.8916491347889 43.26729299226223 481.62129729533007 44.18214103600045 481.62129729533007 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_5-42fd6" fill="#099957" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_6" class="path firer commentable non-processed" customid="Minus"   datasizewidth="20.7px" datasizeheight="13.0px" dataX="232.0" dataY="473.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="21.712848663330078" height="14.003900527954102" viewBox="231.99999999999997 472.98827052116377 21.712848663330078 14.003900527954102" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_6-42fd6" d="M233.89819183935194 486.49217009544356 L251.8147578005463 486.49217009544356 C252.5694835672386 486.49217009544356 253.21284961700437 483.58366569698404 253.21284961700437 479.99054521378935 C253.21284961700437 476.45452764328854 252.5694835672386 473.48827052116377 251.8147578005463 473.48827052116377 L233.89819183935194 473.48827052116377 C233.1681589728539 473.48827052116377 232.49999999999997 476.45452764328854 232.49999999999997 479.99054521378935 C232.49999999999997 483.58366569698404 233.1681589728539 486.49217009544356 233.89819183935194 486.49217009544356 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_6-42fd6" fill="#099957" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="richtext autofit firer ie-background commentable non-processed" customid="Total: 23"   datasizewidth="62.3px" datasizeheight="18.0px" dataX="79.2" dataY="471.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Total: 23</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_8" class="richtext manualfit firer ie-background commentable non-processed" customid="Faltan inv.: 0"   datasizewidth="100.5px" datasizeheight="18.0px" dataX="267.5" dataY="471.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_8_0">Faltan inv.: 0</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="379.0px" datasizeheight="108.0px" dataX="25.5" dataY="274.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;