var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705369689725.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-eca306c7-e78e-43bc-a96a-733ce12f7c8c" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Inventario_5"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/eca306c7-e78e-43bc-a96a-733ce12f7c8c-1705369689725.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="430.0px" datasizeheight="100.0px" dataX="-0.0" dataY="51.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b8230ca2-e75d-4ee5-98b4-ffe594b58999.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="381.0px" datasizeheight="201.0px" datasizewidthpx="381.0" datasizeheightpx="201.00000000000003" dataX="24.5" dataY="285.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Seleccione la acci&oacute;n a re"   datasizewidth="359.9px" datasizeheight="28.0px" dataX="35.0" dataY="350.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Seleccione la acci&oacute;n a realizar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Grabar"   datasizewidth="150.0px" datasizeheight="45.0px" dataX="50.0" dataY="405.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Grabar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="Finalizar"   datasizewidth="150.0px" datasizeheight="45.0px" dataX="225.0" dataY="405.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Finalizar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_37" class="path firer commentable non-processed" customid="Multiply"   datasizewidth="30.2px" datasizeheight="32.2px" dataX="352.0" dataY="297.8"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="30.177913665771484" height="32.178932189941406" viewBox="351.9999999933843 297.8210664198595 30.177913665771484 32.178932189941406" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_37-eca30" d="M352.6010047005362 326.1279459182221 C351.81528289992485 326.9656156077934 351.7778644828841 328.46165995274197 352.61971441653503 329.3392706196312 C353.44283433504853 330.2168856152271 354.8459107914205 330.1971380549665 355.63163360698877 329.3592432726435 L367.08070298244843 317.1319171377964 L378.54852470209784 329.3592432726435 C379.35289024650774 330.2168856152271 380.7372793159333 330.2168856152271 381.560592076263 329.3392706196312 C382.36495762067295 328.44168729972967 382.38368966572415 326.98558393209896 381.560592076263 326.1279459182221 L370.1112872307962 313.900619783375 L381.560592076263 301.69324249365303 C382.38368966572415 300.8355341382913 382.38368966572415 299.35948084335877 381.560592076263 298.48182472504857 C380.7185472708821 297.6241163696868 379.35289024650774 297.6041675245617 378.54852470209784 298.46187587992347 L367.08070298244843 310.68929291761265 L355.63163360698877 298.46187587992347 C354.8459107914205 297.6241163696868 353.42412461904973 297.58421867943656 352.61971441653503 298.48182472504857 C351.7965741988829 299.35948084335877 351.81528289992485 300.85548298341644 352.6010047005362 301.69324249365303 L364.06884671932414 313.900619783375 L352.6010047005362 326.1279459182221 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_37-eca30" fill="#FF0000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="150.0px" datasizeheight="40.0px" dataX="50.0" dataY="410.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="150.0px" datasizeheight="40.0px" dataX="225.0" dataY="410.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;