var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705369689725.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-e0f70fff-f111-40a0-994c-f2b4367d6b23" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Escanear QR_1.1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/e0f70fff-f111-40a0-994c-f2b4367d6b23-1705369689725.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="430.0px" datasizeheight="100.0px" dataX="-0.0" dataY="49.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/7bfac97d-ad02-42f6-81bc-79d780bfc913.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="352.0px" datasizeheight="312.0px" dataX="39.0" dataY="280.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/18eab167-9aaa-49ce-b5a0-b72cc4cc4aff.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="282.0px" datasizeheight="246.0px" dataX="71.0" dataY="313.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;