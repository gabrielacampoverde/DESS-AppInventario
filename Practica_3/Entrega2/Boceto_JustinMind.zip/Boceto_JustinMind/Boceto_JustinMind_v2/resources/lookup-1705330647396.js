(function(window, undefined) {
  var dictionary = {
    "001642c2-3cd5-41a9-91b5-a033e8d733f7": "escaner_qr4",
    "f4f7ef99-a018-4ba0-a85a-b4083f5c6a42": "bienvenido",
    "b35c0565-dab8-4bff-9976-805e221eb2f2": "Menu",
    "7e4eae81-1c2d-4173-80df-c559c13c6281": "registro_inventario",
    "488715fb-7c82-44af-bf3d-6379050841c3": "reporte_inventario3",
    "61e8e888-a958-4a50-ba4c-4cf2258c9d4d": "escaner_qr3",
    "86043a78-f870-4e54-8776-7b0e93a96f54": "registro_inventario4",
    "b4dd4ac9-49f5-42d5-9a7d-1074e9071c7e": "registro_inventario2",
    "0b260bce-9ceb-48d2-942b-831c23b64bfe": "buscar_activo",
    "53fbae56-a864-40c3-9c18-84ad0f6d46fb": "camara",
    "fc6f769a-f5b4-4536-9af3-f2eb0398bc8f": "buscar_activo2",
    "8c166ee7-4c2d-4534-81d9-18c0f4a9367c": "escaner_qr2",
    "5f603492-d709-45fc-a4e1-111f32ad5f10": "registro_inventario3",
    "ddd0d1a4-c294-4054-b6ad-d97aa41f3082": "reporte_inventario",
    "25530b2e-a419-4599-9dd0-b0d9048aeed6": "reporte_inventario2",
    "61bd9d31-830c-47fc-abc4-a10b4f725cd2": "escanear_qr",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "inicio",
    "d7630b75-fed0-46a2-8e56-d302c601069c": "reporte_inventario4",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);