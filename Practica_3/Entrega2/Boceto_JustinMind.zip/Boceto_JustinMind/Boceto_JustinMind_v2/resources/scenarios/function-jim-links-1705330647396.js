(function(window, undefined) {

  var jimLinks = {
    "001642c2-3cd5-41a9-91b5-a033e8d733f7" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_2" : [
        "f4f7ef99-a018-4ba0-a85a-b4083f5c6a42"
      ]
    },
    "f4f7ef99-a018-4ba0-a85a-b4083f5c6a42" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_3" : [
        "7e4eae81-1c2d-4173-80df-c559c13c6281"
      ],
      "Hotspot_5" : [
        "ddd0d1a4-c294-4054-b6ad-d97aa41f3082"
      ],
      "Hotspot_2" : [
        "0b260bce-9ceb-48d2-942b-831c23b64bfe"
      ],
      "Hotspot_4" : [
        "61bd9d31-830c-47fc-abc4-a10b4f725cd2"
      ]
    },
    "b35c0565-dab8-4bff-9976-805e221eb2f2" : {
      "Hotspot_1" : [
        "f4f7ef99-a018-4ba0-a85a-b4083f5c6a42"
      ],
      "Hotspot_2" : [
        "f4f7ef99-a018-4ba0-a85a-b4083f5c6a42"
      ],
      "Hotspot_3" : [
        "0b260bce-9ceb-48d2-942b-831c23b64bfe"
      ],
      "Hotspot_4" : [
        "7e4eae81-1c2d-4173-80df-c559c13c6281"
      ],
      "Hotspot_5" : [
        "61bd9d31-830c-47fc-abc4-a10b4f725cd2"
      ],
      "Hotspot_6" : [
        "f4f7ef99-a018-4ba0-a85a-b4083f5c6a42"
      ],
      "Hotspot_7" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "7e4eae81-1c2d-4173-80df-c559c13c6281" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_2" : [
        "b4dd4ac9-49f5-42d5-9a7d-1074e9071c7e"
      ]
    },
    "488715fb-7c82-44af-bf3d-6379050841c3" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_2" : [
        "d7630b75-fed0-46a2-8e56-d302c601069c"
      ],
      "Hotspot_3" : [
        "25530b2e-a419-4599-9dd0-b0d9048aeed6"
      ]
    },
    "61e8e888-a958-4a50-ba4c-4cf2258c9d4d" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_3" : [
        "8c166ee7-4c2d-4534-81d9-18c0f4a9367c"
      ],
      "Hotspot_2" : [
        "001642c2-3cd5-41a9-91b5-a033e8d733f7"
      ]
    },
    "86043a78-f870-4e54-8776-7b0e93a96f54" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_2" : [
        "488715fb-7c82-44af-bf3d-6379050841c3"
      ],
      "Hotspot_3" : [
        "f4f7ef99-a018-4ba0-a85a-b4083f5c6a42"
      ]
    },
    "b4dd4ac9-49f5-42d5-9a7d-1074e9071c7e" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_2" : [
        "5f603492-d709-45fc-a4e1-111f32ad5f10"
      ]
    },
    "0b260bce-9ceb-48d2-942b-831c23b64bfe" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_2" : [
        "fc6f769a-f5b4-4536-9af3-f2eb0398bc8f"
      ],
      "Hotspot_3" : [
        "53fbae56-a864-40c3-9c18-84ad0f6d46fb"
      ]
    },
    "53fbae56-a864-40c3-9c18-84ad0f6d46fb" : {
      "Hotspot_1" : [
        "f4f7ef99-a018-4ba0-a85a-b4083f5c6a42"
      ],
      "Hotspot_2" : [
        "8c166ee7-4c2d-4534-81d9-18c0f4a9367c"
      ]
    },
    "fc6f769a-f5b4-4536-9af3-f2eb0398bc8f" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ]
    },
    "8c166ee7-4c2d-4534-81d9-18c0f4a9367c" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_2" : [
        "53fbae56-a864-40c3-9c18-84ad0f6d46fb"
      ],
      "Hotspot_3" : [
        "61e8e888-a958-4a50-ba4c-4cf2258c9d4d"
      ],
      "Hotspot_4" : [
        "f4f7ef99-a018-4ba0-a85a-b4083f5c6a42"
      ]
    },
    "5f603492-d709-45fc-a4e1-111f32ad5f10" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_2" : [
        "86043a78-f870-4e54-8776-7b0e93a96f54"
      ]
    },
    "ddd0d1a4-c294-4054-b6ad-d97aa41f3082" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_2" : [
        "25530b2e-a419-4599-9dd0-b0d9048aeed6"
      ]
    },
    "25530b2e-a419-4599-9dd0-b0d9048aeed6" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_2" : [
        "488715fb-7c82-44af-bf3d-6379050841c3"
      ],
      "Hotspot_3" : [
        "488715fb-7c82-44af-bf3d-6379050841c3"
      ]
    },
    "61bd9d31-830c-47fc-abc4-a10b4f725cd2" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_2" : [
        "53fbae56-a864-40c3-9c18-84ad0f6d46fb"
      ],
      "Hotspot_3" : [
        "f4f7ef99-a018-4ba0-a85a-b4083f5c6a42"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Hotspot_1" : [
        "f4f7ef99-a018-4ba0-a85a-b4083f5c6a42"
      ]
    },
    "d7630b75-fed0-46a2-8e56-d302c601069c" : {
      "Hotspot_1" : [
        "b35c0565-dab8-4bff-9976-805e221eb2f2"
      ],
      "Hotspot_2" : [
        "f4f7ef99-a018-4ba0-a85a-b4083f5c6a42"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);