var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705369689725.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-53ec5e95-908b-4339-8524-af132177c246" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Escanear QR_2"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/53ec5e95-908b-4339-8524-af132177c246-1705369689725.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="430.0px" datasizeheight="100.0px" dataX="-0.0" dataY="49.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/7bfac97d-ad02-42f6-81bc-79d780bfc913.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Escanear C&oacute;digo QR"   datasizewidth="247.0px" datasizeheight="51.0px" dataX="91.5" dataY="211.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Escanear C&oacute;digo QR</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="Salir"   datasizewidth="151.0px" datasizeheight="51.0px" dataX="239.0" dataY="629.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Salir</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_3" class="button multiline manualfit firer commentable non-processed" customid="Grabar"   datasizewidth="168.0px" datasizeheight="51.0px" dataX="31.9" dataY="629.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_3_0">Grabar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="416.0px" datasizeheight="221.0px" datasizewidthpx="415.99999999999994" datasizeheightpx="221.0" dataX="8.0" dataY="309.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="UCSM - Inventario"   datasizewidth="177.8px" datasizeheight="22.0px" dataX="27.0" dataY="322.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">UCSM - Inventario </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="C&oacute;digo: 05-003-0051 Descr"   datasizewidth="399.3px" datasizeheight="144.0px" dataX="21.7" dataY="354.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">C&oacute;digo:</span><span id="rtr-s-Paragraph_2_1"> 05-003-0051 <br /></span><span id="rtr-s-Paragraph_2_2">Descripci&oacute;n:</span><span id="rtr-s-Paragraph_2_3"> Audifono con micr&oacute;fono EAR H390<br /></span><span id="rtr-s-Paragraph_2_4">Centro de Resp:</span><span id="rtr-s-Paragraph_2_5"> 00095-E.P.Ing. de Sistemas-Direcci&oacute;n<br /></span><span id="rtr-s-Paragraph_2_6">Emp. Resp:</span><span id="rtr-s-Paragraph_2_7"> 1221 - Fernando Paredes<br /></span><span id="rtr-s-Paragraph_2_8">Tipo: </span><span id="rtr-s-Paragraph_2_9">05003 - Equipo de Computaci&oacute;n<br /></span><span id="rtr-s-Paragraph_2_10">Marca: </span><span id="rtr-s-Paragraph_2_11">Logitech<br /></span><span id="rtr-s-Paragraph_2_12">Modelo: </span><span id="rtr-s-Paragraph_2_13">H390<br /></span><span id="rtr-s-Paragraph_2_14">Nro. Serie:</span><span id="rtr-s-Paragraph_2_15"> 255SDS222SA</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="257.3px" datasizeheight="51.0px" dataX="91.5" dataY="211.5"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="158.0px" datasizeheight="51.0px" dataX="31.9" dataY="629.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="151.0px" datasizeheight="51.0px" dataX="239.0" dataY="629.5"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;