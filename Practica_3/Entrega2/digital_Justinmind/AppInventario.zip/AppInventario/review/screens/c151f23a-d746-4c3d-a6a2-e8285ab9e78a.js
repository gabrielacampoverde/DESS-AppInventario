var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705369689725.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-c151f23a-d746-4c3d-a6a2-e8285ab9e78a" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Perfil"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/c151f23a-d746-4c3d-a6a2-e8285ab9e78a-1705369689725.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="430.0px" datasizeheight="100.0px" dataX="0.0" dataY="59.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b277bb93-79c5-4f6f-bb30-be9624543377.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext manualfit firer commentable non-processed" customid="Perfil"   datasizewidth="268.0px" datasizeheight="38.0px" dataX="65.0" dataY="95.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Perfil</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="379.0px" datasizeheight="209.0px" datasizewidthpx="378.9999999999998" datasizeheightpx="209.0000000000001" dataX="34.5" dataY="445.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Nro. Dni: 75126482 email:"   datasizewidth="335.0px" datasizeheight="154.8px" dataX="78.5" dataY="478.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Nro. Dni: </span><span id="rtr-s-Paragraph_2_1">75126482<br /></span><span id="rtr-s-Paragraph_2_2"> <br />email: </span><span id="rtr-s-Paragraph_2_3">kritel@ucs.edu.pe<br /><br /></span><span id="rtr-s-Paragraph_2_4">Nro. Celular:</span><span id="rtr-s-Paragraph_2_5"> 96325123</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="379.0px" datasizeheight="170.0px" datasizewidthpx="378.9999999999998" datasizeheightpx="170.0000000000001" dataX="34.5" dataY="242.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Kristel Alvarez Subia"   datasizewidth="315.0px" datasizeheight="40.0px" dataX="66.5" dataY="347.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Kristel Alvarez Subia</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_63" class="path firer commentable non-processed" customid="Person"   datasizewidth="75.5px" datasizeheight="66.4px" dataX="186.3" dataY="263.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="75.4599838256836" height="66.42677307128906" viewBox="186.27001047134434 263.0 75.4599838256836 66.42677307128906" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_63-c151f" d="M224.02142870929976 296.37346059073514 C234.40329506795234 296.37346059073514 242.81128101744378 288.76745291787495 242.81128101744378 279.4556047173662 C242.81128101744378 270.2859391391327 234.40329506795234 263.0 224.02142870929976 263.0 C213.6825175215855 263.0 205.18862123021734 270.3925746596592 205.2315764011557 279.5266950643839 C205.27452691722078 288.80304051266063 213.63956700552043 296.37346059073514 224.02142870929976 296.37346059073514 Z M224.02142870929976 290.15367226344273 C218.10127704127655 290.15367226344273 213.08215523595715 285.49762861231727 213.08215523595715 279.5266950643839 C213.0392047198921 273.6979036456887 218.05832652521147 269.2197073412184 224.02142870929976 269.2197073412184 C230.0274860643264 269.2197073412184 234.960697527769 273.6268557199479 234.960697527769 279.4556047173662 C234.960697527769 285.42645727922564 229.984530893388 290.15367226344273 224.02142870929976 290.15367226344273 Z M197.252234460752 329.42676973342896 L250.7477655392487 329.42676973342896 C258.16930935560407 329.42676973342896 261.72998952865635 327.47198958386775 261.72998952865635 323.27815273922823 C261.72998952865635 313.50425970438147 247.0152739921895 300.496126102283 224.02142870929976 300.496126102283 C201.0273832668575 300.496126102283 186.27001047134434 313.50425970438147 186.27001047134434 323.27815273922823 C186.27001047134434 327.47198958386775 189.8306906443966 329.42676973342896 197.252234460752 329.42676973342896 Z M195.92236042940797 323.2069852626163 C194.89281416938752 323.2069852626163 194.50667846340008 322.92270100413987 194.50667846340008 322.2829727235345 C194.50667846340008 316.84525919951045 205.10271554321386 306.7159144295753 224.02142870929976 306.7159144295753 C242.89719135932057 306.7159144295753 253.4933215366006 316.84525919951045 253.4933215366006 322.2829727235345 C253.4933215366006 322.92270100413987 253.10723703421962 323.2069852626163 252.07734631357397 323.2069852626163 L195.92236042940797 323.2069852626163 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_63-c151f" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="100.0px" datasizeheight="80.0px" dataX="0.0" dataY="69.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;