var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705369689725.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-b8ef45a4-1ea4-4f13-b2e6-e719bf121ec8" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Inventario_2"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/b8ef45a4-1ea4-4f13-b2e6-e719bf121ec8-1705369689725.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="430.0px" datasizeheight="100.0px" dataX="0.0" dataY="47.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/546283a6-7cd8-4860-bf37-35c40ca9bb6f.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="Centro de Responsabilidad"   datasizewidth="323.7px" datasizeheight="28.0px" dataX="53.2" dataY="185.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Centro de Responsabilidad</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="379.0px" datasizeheight="114.0px" datasizewidthpx="379.0" datasizeheightpx="114.0" dataX="25.5" dataY="244.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="00994 - E.P. Ing. de Sist"   datasizewidth="306.8px" datasizeheight="18.0px" dataX="42.5" dataY="262.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">00994 - E.P. Ing. de Sistemas - Direcci&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Line_1" class="path firer commentable non-processed" customid="Line 1"   datasizewidth="347.0px" datasizeheight="3.3px" dataX="42.0" dataY="289.4"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="346.00360107421875" height="3.249993324279785" viewBox="41.99818843603134 289.4470222160082 346.00360107421875 3.249993324279785" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Line_1-b8ef4" d="M42.5 290.4470189377527 L387.5 291.6970189377527 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Line_1-b8ef4" fill="#000000" fill-opacity="1.0" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_29" class="path firer commentable non-processed" customid="Plus"   datasizewidth="24.7px" datasizeheight="24.0px" dataX="42.5" dataY="309.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="24.730430603027344" height="23.980440139770508" viewBox="42.5 308.9999999999998 24.730430603027344 23.980440139770508" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_29-b8ef4" d="M44.18214103600045 322.62129729533007 L53.183015987503964 322.62129729533007 L53.183015987503964 331.3493935158872 C53.183015987503964 332.2364656595221 53.93565098113054 332.98044061660744 54.86524028029623 332.98044061660744 C55.79482957946192 332.98044061660744 56.54746457308849 332.2364656595221 56.54746457308849 331.3493935158872 L56.54746457308849 322.62129729533007 L65.54837394807323 322.62129729533007 C66.46318676778415 322.62129729533007 67.23043012618973 321.8916491347889 67.23043012618973 320.9902517471452 C67.23043012618973 320.0888559120368 66.46318676778415 319.3590447352801 65.54837394807323 319.3590447352801 L56.54746457308849 319.3590447352801 L56.54746457308849 310.6311418053786 C56.54746457308849 309.7440223094144 55.79482957946192 308.9999999999998 54.86524028029623 308.9999999999998 C53.93565098113054 308.9999999999998 53.183015987503964 309.7440223094144 53.183015987503964 310.6311418053786 L53.183015987503964 319.3590447352801 L44.18214103600045 319.3590447352801 C43.26729299226223 319.3590447352801 42.5 320.0888559120368 42.5 320.9902517471452 C42.5 321.8916491347889 43.26729299226223 322.62129729533007 44.18214103600045 322.62129729533007 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_29-b8ef4" fill="#099957" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_26" class="path firer commentable non-processed" customid="Minus"   datasizewidth="20.7px" datasizeheight="13.0px" dataX="232.0" dataY="314.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="21.712848663330078" height="14.003900527954102" viewBox="231.99999999999997 313.98827052116377 21.712848663330078 14.003900527954102" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_26-b8ef4" d="M233.89819183935194 327.49217009544356 L251.8147578005463 327.49217009544356 C252.5694835672386 327.49217009544356 253.21284961700437 324.58366569698404 253.21284961700437 320.99054521378935 C253.21284961700437 317.45452764328854 252.5694835672386 314.48827052116377 251.8147578005463 314.48827052116377 L233.89819183935194 314.48827052116377 C233.1681589728539 314.48827052116377 232.49999999999997 317.45452764328854 232.49999999999997 320.99054521378935 C232.49999999999997 324.58366569698404 233.1681589728539 327.49217009544356 233.89819183935194 327.49217009544356 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_26-b8ef4" fill="#099957" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext autofit firer ie-background commentable non-processed" customid="Total: 18"   datasizewidth="62.3px" datasizeheight="18.0px" dataX="79.2" dataY="312.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">Total: 18</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="Faltan inv.: 10"   datasizewidth="100.5px" datasizeheight="18.0px" dataX="267.5" dataY="312.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Faltan inv.: 10</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="379.0px" datasizeheight="114.0px" datasizewidthpx="379.0" datasizeheightpx="114.0" dataX="25.5" dataY="379.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_5" class="richtext autofit firer ie-background commentable non-processed" customid="00994 - E.P. Ing. de Sist"   datasizewidth="311.3px" datasizeheight="18.0px" dataX="42.5" dataY="397.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_5_0">00994 - E.P. Ing. de Sistemas - Secretaria</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="Line 1"   datasizewidth="347.0px" datasizeheight="3.3px" dataX="42.0" dataY="424.4"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="346.00360107421875" height="3.249993324279785" viewBox="41.99818843603134 424.4470222160082 346.00360107421875 3.249993324279785" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-b8ef4" d="M42.5 425.4470189377527 L387.5 426.6970189377527 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-b8ef4" fill="#000000" fill-opacity="1.0" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="Plus"   datasizewidth="24.7px" datasizeheight="24.0px" dataX="42.5" dataY="444.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="24.730430603027344" height="23.980440139770508" viewBox="42.5 443.9999999999998 24.730430603027344 23.980440139770508" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-b8ef4" d="M44.18214103600045 457.62129729533007 L53.183015987503964 457.62129729533007 L53.183015987503964 466.3493935158872 C53.183015987503964 467.2364656595221 53.93565098113054 467.98044061660744 54.86524028029623 467.98044061660744 C55.79482957946192 467.98044061660744 56.54746457308849 467.2364656595221 56.54746457308849 466.3493935158872 L56.54746457308849 457.62129729533007 L65.54837394807323 457.62129729533007 C66.46318676778415 457.62129729533007 67.23043012618973 456.8916491347889 67.23043012618973 455.9902517471452 C67.23043012618973 455.0888559120368 66.46318676778415 454.3590447352801 65.54837394807323 454.3590447352801 L56.54746457308849 454.3590447352801 L56.54746457308849 445.6311418053786 C56.54746457308849 444.7440223094144 55.79482957946192 443.9999999999998 54.86524028029623 443.9999999999998 C53.93565098113054 443.9999999999998 53.183015987503964 444.7440223094144 53.183015987503964 445.6311418053786 L53.183015987503964 454.3590447352801 L44.18214103600045 454.3590447352801 C43.26729299226223 454.3590447352801 42.5 455.0888559120368 42.5 455.9902517471452 C42.5 456.8916491347889 43.26729299226223 457.62129729533007 44.18214103600045 457.62129729533007 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-b8ef4" fill="#099957" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer commentable non-processed" customid="Minus"   datasizewidth="20.7px" datasizeheight="13.0px" dataX="232.0" dataY="449.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="21.712848663330078" height="14.003900527954102" viewBox="231.99999999999997 448.98827052116377 21.712848663330078 14.003900527954102" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-b8ef4" d="M233.89819183935194 462.49217009544356 L251.8147578005463 462.49217009544356 C252.5694835672386 462.49217009544356 253.21284961700437 459.58366569698404 253.21284961700437 455.99054521378935 C253.21284961700437 452.45452764328854 252.5694835672386 449.48827052116377 251.8147578005463 449.48827052116377 L233.89819183935194 449.48827052116377 C233.1681589728539 449.48827052116377 232.49999999999997 452.45452764328854 232.49999999999997 455.99054521378935 C232.49999999999997 459.58366569698404 233.1681589728539 462.49217009544356 233.89819183935194 462.49217009544356 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-b8ef4" fill="#099957" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_6" class="richtext autofit firer ie-background commentable non-processed" customid="Total: 23"   datasizewidth="62.3px" datasizeheight="18.0px" dataX="79.2" dataY="447.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_6_0">Total: 23</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_7" class="richtext manualfit firer ie-background commentable non-processed" customid="Faltan inv.: 9"   datasizewidth="100.5px" datasizeheight="18.0px" dataX="267.5" dataY="447.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">Faltan inv.: 9</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="373.0px" datasizeheight="101.0px" dataX="25.5" dataY="250.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;