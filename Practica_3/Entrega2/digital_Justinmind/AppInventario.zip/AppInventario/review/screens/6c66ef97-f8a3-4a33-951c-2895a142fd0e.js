var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705369689725.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-6c66ef97-f8a3-4a33-951c-2895a142fd0e" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Inventario_3"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/6c66ef97-f8a3-4a33-951c-2895a142fd0e-1705369689725.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="430.0px" datasizeheight="100.0px" dataX="-0.0" dataY="51.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/4ad42a8d-e6bc-4812-b162-6da1dee60a4b.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext autofit firer ie-background commentable non-processed" customid="E.P. Ing. de Sistemas - D"   datasizewidth="387.6px" datasizeheight="28.0px" dataX="21.2" dataY="164.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">E.P. Ing. de Sistemas - Direcci&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="387.6px" datasizeheight="43.8px" dataX="21.2" dataY="234.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0012 PC Core 2Duo"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="387.6px" datasizeheight="43.8px" dataX="21.2" dataY="277.7" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0013 Teclado multimedia Pro"/></div></div>  </div></div></div>\
      <div id="s-Input_3" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="387.6px" datasizeheight="43.8px" dataX="21.2" dataY="365.2" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0054 Mouse Dell USB Optical"/></div></div>  </div></div></div>\
      <div id="s-Input_4" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="387.6px" datasizeheight="43.8px" dataX="21.2" dataY="496.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0018 Laptop MBP 13.3/2.7"/></div></div>  </div></div></div>\
      <div id="s-Input_5" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="387.6px" datasizeheight="43.8px" dataX="21.3" dataY="627.8" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0028 Impresora EPSON L6171"/></div></div>  </div></div></div>\
      <div id="s-Input_6" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="387.6px" datasizeheight="43.8px" dataX="21.3" dataY="671.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0032 Notebook thikpad T16"/></div></div>  </div></div></div>\
      <div id="s-Input_7" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="387.6px" datasizeheight="43.8px" dataX="21.2" dataY="715.3" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0051 Audifonos con micr&oacute;fono"/></div></div>  </div></div></div>\
      <div id="s-Input_8" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="387.6px" datasizeheight="43.8px" dataX="21.2" dataY="540.2" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0019 Laptop MBP 13.3/2.7"/></div></div>  </div></div></div>\
      <div id="s-Input_9" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="387.6px" datasizeheight="43.8px" dataX="21.2" dataY="584.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0025 Laptop MBP 13.3/2.7"/></div></div>  </div></div></div>\
      <div id="s-Input_10" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="387.6px" datasizeheight="43.8px" dataX="21.2" dataY="321.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0014 Teclado multimedi&lt;a Pro"/></div></div>  </div></div></div>\
      <div id="s-Input_11" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="387.6px" datasizeheight="43.8px" dataX="21.0" dataY="409.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0016 Mouse Dell USB Optical"/></div></div>  </div></div></div>\
      <div id="s-Input_12" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="387.6px" datasizeheight="43.8px" dataX="21.2" dataY="452.8" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0017 Mouse Dell USB Optical"/></div></div>  </div></div></div>\
      <div id="s-Input_13" class="inputIOS checkbox firer commentable non-processed unchecked" customid="Input 13"  datasizewidth="16.0px" datasizeheight="16.0px" dataX="375.0" dataY="247.9"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_14" class="inputIOS checkbox firer commentable non-processed unchecked" customid="Input 14"  datasizewidth="16.0px" datasizeheight="16.0px" dataX="375.0" dataY="291.6"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Path_15" class="path firer commentable non-processed" customid="Chevron down"   datasizewidth="15.6px" datasizeheight="9.0px" dataX="348.0" dataY="251.4"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.591800689697266" height="8.982439994812012" viewBox="348.0 251.38378000259405 15.591800689697266 8.982439994812012" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_15-6c66e" d="M355.7958998680115 260.36621999740606 C356.1034998893738 260.35741949081427 356.38479948043823 260.24311971664434 356.61329984664917 259.99702024459845 L363.2930006980896 253.15912008285528 C363.48629903793335 252.9658198356629 363.5918002128601 252.71971940994268 363.5918002128601 252.42971944808966 C363.5918002128601 251.84959936141973 363.13479948043823 251.38378000259405 362.55470037460327 251.38378000259405 C362.2734007835388 251.38378000259405 362.00099897384644 251.49803972244268 361.79879903793335 251.70019006729132 L355.80469942092896 257.86132001876837 L349.7929697036743 251.70019006729132 C349.59081983566284 251.506829738617 349.3271498680115 251.38378000259405 349.03710985183716 251.38378000259405 C348.4570298194885 251.38378000259405 348.0 251.84959936141973 348.0 252.42971944808966 C348.0 252.71971940994268 348.1054697036743 252.9658198356629 348.29883003234863 253.15912008285528 L354.98729944229126 259.99702024459845 C355.224600315094 260.24311971664434 355.48829984664917 260.36621999740606 355.7958998680115 260.36621999740606 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_15-6c66e" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_16" class="path firer commentable non-processed" customid="Chevron down"   datasizewidth="15.6px" datasizeheight="9.0px" dataX="348.0" dataY="295.1"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.591800689697266" height="8.982439994812012" viewBox="348.0000000000001 295.1337800025942 15.591800689697266 8.982439994812012" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_16-6c66e" d="M355.7958998680116 304.11621999740623 C356.1034998893739 304.10741949081444 356.38479948043835 303.9931197166445 356.6132998466493 303.7470202445986 L363.2930006980897 296.90912008285545 C363.48629903793346 296.71581983566307 363.5918002128602 296.46971940994285 363.5918002128602 296.1797194480898 C363.5918002128602 295.5995993614199 363.13479948043835 295.1337800025942 362.5547003746034 295.1337800025942 C362.27340078353893 295.1337800025942 362.00099897384655 295.24803972244285 361.79879903793346 295.4501900672915 L355.80469942092907 301.61132001876854 L349.79296970367443 295.4501900672915 C349.59081983566296 295.25682973861717 349.3271498680116 295.1337800025942 349.0371098518373 295.1337800025942 C348.45702981948864 295.1337800025942 348.0000000000001 295.5995993614199 348.0000000000001 296.1797194480898 C348.0000000000001 296.46971940994285 348.10546970367443 296.71581983566307 348.29883003234875 296.90912008285545 L354.9872994422914 303.7470202445986 C355.2246003150941 303.9931197166445 355.4882998466493 304.11621999740623 355.7958998680116 304.11621999740623 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_16-6c66e" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_17" class="path firer commentable non-processed" customid="Chevron down"   datasizewidth="15.6px" datasizeheight="9.0px" dataX="348.0" dataY="338.9"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.591800689697266" height="8.982439994812012" viewBox="348.0000000000001 338.88378000259405 15.591800689697266 8.982439994812012" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_17-6c66e" d="M355.7958998680116 347.86621999740606 C356.1034998893739 347.85741949081427 356.38479948043835 347.74311971664434 356.6132998466493 347.49702024459845 L363.2930006980897 340.6591200828553 C363.48629903793346 340.4658198356629 363.5918002128602 340.2197194099427 363.5918002128602 339.92971944808966 C363.5918002128602 339.34959936141973 363.13479948043835 338.88378000259405 362.5547003746034 338.88378000259405 C362.27340078353893 338.88378000259405 362.00099897384655 338.9980397224427 361.79879903793346 339.2001900672913 L355.80469942092907 345.36132001876837 L349.79296970367443 339.2001900672913 C349.59081983566296 339.006829738617 349.3271498680116 338.88378000259405 349.0371098518373 338.88378000259405 C348.45702981948864 338.88378000259405 348.0000000000001 339.34959936141973 348.0000000000001 339.92971944808966 C348.0000000000001 340.2197194099427 348.10546970367443 340.4658198356629 348.29883003234875 340.6591200828553 L354.9872994422914 347.49702024459845 C355.2246003150941 347.74311971664434 355.4882998466493 347.86621999740606 355.7958998680116 347.86621999740606 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_17-6c66e" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_18" class="path firer commentable non-processed" customid="Chevron down"   datasizewidth="15.6px" datasizeheight="9.0px" dataX="348.0" dataY="378.1"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.591800689697266" height="8.982439994812012" viewBox="348.0000000000001 378.14256000518805 15.591800689697266 8.982439994812012" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_18-6c66e" d="M355.7958998680116 387.12500000000006 C356.1034998893739 387.11619949340826 356.38479948043835 387.00189971923834 356.6132998466493 386.75580024719244 L363.2930006980897 379.9179000854493 C363.48629903793346 379.7245998382569 363.5918002128602 379.4784994125367 363.5918002128602 379.18849945068365 C363.5918002128602 378.60837936401373 363.13479948043835 378.14256000518805 362.5547003746034 378.14256000518805 C362.27340078353893 378.14256000518805 362.00099897384655 378.2568197250367 361.79879903793346 378.4589700698853 L355.80469942092907 384.62010002136236 L349.79296970367443 378.4589700698853 C349.59081983566296 378.265609741211 349.3271498680116 378.14256000518805 349.0371098518373 378.14256000518805 C348.45702981948864 378.14256000518805 348.0000000000001 378.60837936401373 348.0000000000001 379.18849945068365 C348.0000000000001 379.4784994125367 348.10546970367443 379.7245998382569 348.29883003234875 379.9179000854493 L354.9872994422914 386.75580024719244 C355.2246003150941 387.00189971923834 355.4882998466493 387.12500000000006 355.7958998680116 387.12500000000006 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_18-6c66e" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_19" class="path firer commentable non-processed" customid="Chevron down"   datasizewidth="15.6px" datasizeheight="9.0px" dataX="348.0" dataY="426.4"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.591800689697266" height="8.982439994812012" viewBox="348.0000000000001 426.38378000259405 15.591800689697266 8.982439994812012" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_19-6c66e" d="M355.7958998680116 435.36621999740606 C356.1034998893739 435.35741949081427 356.38479948043835 435.24311971664434 356.6132998466493 434.99702024459845 L363.2930006980897 428.1591200828553 C363.48629903793346 427.9658198356629 363.5918002128602 427.7197194099427 363.5918002128602 427.42971944808966 C363.5918002128602 426.84959936141973 363.13479948043835 426.38378000259405 362.5547003746034 426.38378000259405 C362.27340078353893 426.38378000259405 362.00099897384655 426.4980397224427 361.79879903793346 426.7001900672913 L355.80469942092907 432.86132001876837 L349.79296970367443 426.7001900672913 C349.59081983566296 426.506829738617 349.3271498680116 426.38378000259405 349.0371098518373 426.38378000259405 C348.45702981948864 426.38378000259405 348.0000000000001 426.84959936141973 348.0000000000001 427.42971944808966 C348.0000000000001 427.7197194099427 348.10546970367443 427.9658198356629 348.29883003234875 428.1591200828553 L354.9872994422914 434.99702024459845 C355.2246003150941 435.24311971664434 355.4882998466493 435.36621999740606 355.7958998680116 435.36621999740606 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_19-6c66e" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_20" class="path firer commentable non-processed" customid="Chevron down"   datasizewidth="15.6px" datasizeheight="9.0px" dataX="348.0" dataY="466.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.591800689697266" height="8.982439994812012" viewBox="348.0000000000001 466.00000000000017 15.591800689697266 8.982439994812012" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_20-6c66e" d="M355.7958998680116 474.9824399948122 C356.1034998893739 474.9736394882204 356.38479948043835 474.85933971405046 356.6132998466493 474.61324024200457 L363.2930006980897 467.7753400802614 C363.48629903793346 467.582039833069 363.5918002128602 467.3359394073488 363.5918002128602 467.0459394454958 C363.5918002128602 466.46581935882585 363.13479948043835 466.00000000000017 362.5547003746034 466.00000000000017 C362.27340078353893 466.00000000000017 362.00099897384655 466.1142597198488 361.79879903793346 466.31641006469744 L355.80469942092907 472.4775400161745 L349.79296970367443 466.31641006469744 C349.59081983566296 466.1230497360231 349.3271498680116 466.00000000000017 349.0371098518373 466.00000000000017 C348.45702981948864 466.00000000000017 348.0000000000001 466.46581935882585 348.0000000000001 467.0459394454958 C348.0000000000001 467.3359394073488 348.10546970367443 467.582039833069 348.29883003234875 467.7753400802614 L354.9872994422914 474.61324024200457 C355.2246003150941 474.85933971405046 355.4882998466493 474.9824399948122 355.7958998680116 474.9824399948122 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_20-6c66e" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_21" class="path firer commentable non-processed" customid="Chevron down"   datasizewidth="15.6px" datasizeheight="9.0px" dataX="348.0" dataY="513.9"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.591800689697266" height="8.982439994812012" viewBox="348.0000000000001 513.883780002594 15.591800689697266 8.982439994812012" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_21-6c66e" d="M355.7958998680116 522.866219997406 C356.1034998893739 522.8574194908142 356.38479948043835 522.7431197166443 356.6132998466493 522.4970202445984 L363.2930006980897 515.6591200828552 C363.48629903793346 515.4658198356628 363.5918002128602 515.2197194099426 363.5918002128602 514.9297194480896 C363.5918002128602 514.3495993614197 363.13479948043835 513.883780002594 362.5547003746034 513.883780002594 C362.27340078353893 513.883780002594 362.00099897384655 513.9980397224426 361.79879903793346 514.2001900672913 L355.80469942092907 520.3613200187683 L349.79296970367443 514.2001900672913 C349.59081983566296 514.006829738617 349.3271498680116 513.883780002594 349.0371098518373 513.883780002594 C348.45702981948864 513.883780002594 348.0000000000001 514.3495993614197 348.0000000000001 514.9297194480896 C348.0000000000001 515.2197194099426 348.10546970367443 515.4658198356628 348.29883003234875 515.6591200828552 L354.9872994422914 522.4970202445984 C355.2246003150941 522.7431197166443 355.4882998466493 522.866219997406 355.7958998680116 522.866219997406 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_21-6c66e" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_22" class="path firer commentable non-processed" customid="Chevron down"   datasizewidth="15.6px" datasizeheight="9.0px" dataX="348.0" dataY="557.6"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.591800689697266" height="8.982439994812012" viewBox="348.0000000000001 557.6337800025938 15.591800689697266 8.982439994812012" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_22-6c66e" d="M355.7958998680116 566.6162199974058 C356.1034998893739 566.607419490814 356.38479948043835 566.4931197166441 356.6132998466493 566.2470202445982 L363.2930006980897 559.409120082855 C363.48629903793346 559.2158198356626 363.5918002128602 558.9697194099424 363.5918002128602 558.6797194480894 C363.5918002128602 558.0995993614195 363.13479948043835 557.6337800025938 362.5547003746034 557.6337800025938 C362.27340078353893 557.6337800025938 362.00099897384655 557.7480397224424 361.79879903793346 557.950190067291 L355.80469942092907 564.1113200187681 L349.79296970367443 557.950190067291 C349.59081983566296 557.7568297386167 349.3271498680116 557.6337800025938 349.0371098518373 557.6337800025938 C348.45702981948864 557.6337800025938 348.0000000000001 558.0995993614195 348.0000000000001 558.6797194480894 C348.0000000000001 558.9697194099424 348.10546970367443 559.2158198356626 348.29883003234875 559.409120082855 L354.9872994422914 566.2470202445982 C355.2246003150941 566.4931197166441 355.4882998466493 566.6162199974058 355.7958998680116 566.6162199974058 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_22-6c66e" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_23" class="path firer commentable non-processed" customid="Chevron down"   datasizewidth="15.6px" datasizeheight="9.0px" dataX="348.0" dataY="601.4"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.591800689697266" height="8.982439994812012" viewBox="348.0000000000001 601.383780002594 15.591800689697266 8.982439994812012" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_23-6c66e" d="M355.7958998680116 610.366219997406 C356.1034998893739 610.3574194908142 356.38479948043835 610.2431197166443 356.6132998466493 609.9970202445984 L363.2930006980897 603.1591200828552 C363.48629903793346 602.9658198356628 363.5918002128602 602.7197194099426 363.5918002128602 602.4297194480896 C363.5918002128602 601.8495993614197 363.13479948043835 601.383780002594 362.5547003746034 601.383780002594 C362.27340078353893 601.383780002594 362.00099897384655 601.4980397224426 361.79879903793346 601.7001900672913 L355.80469942092907 607.8613200187683 L349.79296970367443 601.7001900672913 C349.59081983566296 601.506829738617 349.3271498680116 601.383780002594 349.0371098518373 601.383780002594 C348.45702981948864 601.383780002594 348.0000000000001 601.8495993614197 348.0000000000001 602.4297194480896 C348.0000000000001 602.7197194099426 348.10546970367443 602.9658198356628 348.29883003234875 603.1591200828552 L354.9872994422914 609.9970202445984 C355.2246003150941 610.2431197166443 355.4882998466493 610.366219997406 355.7958998680116 610.366219997406 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_23-6c66e" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_24" class="path firer commentable non-processed" customid="Chevron down"   datasizewidth="15.6px" datasizeheight="9.0px" dataX="348.0" dataY="645.1"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.591800689697266" height="8.982439994812012" viewBox="348.0000000000001 645.133780002594 15.591800689697266 8.982439994812012" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_24-6c66e" d="M355.7958998680116 654.116219997406 C356.1034998893739 654.1074194908142 356.38479948043835 653.9931197166443 356.6132998466493 653.7470202445984 L363.2930006980897 646.9091200828552 C363.48629903793346 646.7158198356628 363.5918002128602 646.4697194099426 363.5918002128602 646.1797194480896 C363.5918002128602 645.5995993614197 363.13479948043835 645.133780002594 362.5547003746034 645.133780002594 C362.27340078353893 645.133780002594 362.00099897384655 645.2480397224426 361.79879903793346 645.4501900672913 L355.80469942092907 651.6113200187683 L349.79296970367443 645.4501900672913 C349.59081983566296 645.256829738617 349.3271498680116 645.133780002594 349.0371098518373 645.133780002594 C348.45702981948864 645.133780002594 348.0000000000001 645.5995993614197 348.0000000000001 646.1797194480896 C348.0000000000001 646.4697194099426 348.10546970367443 646.7158198356628 348.29883003234875 646.9091200828552 L354.9872994422914 653.7470202445984 C355.2246003150941 653.9931197166443 355.4882998466493 654.116219997406 355.7958998680116 654.116219997406 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_24-6c66e" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_25" class="path firer commentable non-processed" customid="Chevron down"   datasizewidth="15.6px" datasizeheight="9.0px" dataX="348.0" dataY="688.9"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.591800689697266" height="8.982439994812012" viewBox="348.0000000000001 688.883780002594 15.591800689697266 8.982439994812012" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_25-6c66e" d="M355.7958998680116 697.866219997406 C356.1034998893739 697.8574194908142 356.38479948043835 697.7431197166443 356.6132998466493 697.4970202445984 L363.2930006980897 690.6591200828552 C363.48629903793346 690.4658198356628 363.5918002128602 690.2197194099426 363.5918002128602 689.9297194480896 C363.5918002128602 689.3495993614197 363.13479948043835 688.883780002594 362.5547003746034 688.883780002594 C362.27340078353893 688.883780002594 362.00099897384655 688.9980397224426 361.79879903793346 689.2001900672913 L355.80469942092907 695.3613200187683 L349.79296970367443 689.2001900672913 C349.59081983566296 689.006829738617 349.3271498680116 688.883780002594 349.0371098518373 688.883780002594 C348.45702981948864 688.883780002594 348.0000000000001 689.3495993614197 348.0000000000001 689.9297194480896 C348.0000000000001 690.2197194099426 348.10546970367443 690.4658198356628 348.29883003234875 690.6591200828552 L354.9872994422914 697.4970202445984 C355.2246003150941 697.7431197166443 355.4882998466493 697.866219997406 355.7958998680116 697.866219997406 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_25-6c66e" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_26" class="path firer commentable non-processed" customid="Chevron down"   datasizewidth="15.6px" datasizeheight="9.0px" dataX="348.0" dataY="732.6"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="15.591800689697266" height="8.982439994812012" viewBox="348.0000000000001 732.633780002594 15.591800689697266 8.982439994812012" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_26-6c66e" d="M355.7958998680116 741.616219997406 C356.1034998893739 741.6074194908142 356.38479948043835 741.4931197166443 356.6132998466493 741.2470202445984 L363.2930006980897 734.4091200828552 C363.48629903793346 734.2158198356628 363.5918002128602 733.9697194099426 363.5918002128602 733.6797194480896 C363.5918002128602 733.0995993614197 363.13479948043835 732.633780002594 362.5547003746034 732.633780002594 C362.27340078353893 732.633780002594 362.00099897384655 732.7480397224426 361.79879903793346 732.9501900672913 L355.80469942092907 739.1113200187683 L349.79296970367443 732.9501900672913 C349.59081983566296 732.756829738617 349.3271498680116 732.633780002594 349.0371098518373 732.633780002594 C348.45702981948864 732.633780002594 348.0000000000001 733.0995993614197 348.0000000000001 733.6797194480896 C348.0000000000001 733.9697194099426 348.10546970367443 734.2158198356628 348.29883003234875 734.4091200828552 L354.9872994422914 741.2470202445984 C355.2246003150941 741.4931197166443 355.4882998466493 741.616219997406 355.7958998680116 741.616219997406 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_26-6c66e" fill="#000000" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_15" class="inputIOS checkbox firer commentable non-processed unchecked" customid="Input 15"  datasizewidth="16.0px" datasizeheight="16.0px" dataX="375.0" dataY="335.4"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_16" class="inputIOS checkbox firer commentable non-processed unchecked" customid="Input 16"  datasizewidth="16.0px" datasizeheight="16.0px" dataX="375.0" dataY="374.6"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_17" class="inputIOS checkbox firer commentable non-processed unchecked" customid="Input 17"  datasizewidth="16.0px" datasizeheight="16.0px" dataX="375.0" dataY="422.9"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_18" class="inputIOS checkbox firer commentable non-processed unchecked" customid="Input 18"  datasizewidth="16.0px" datasizeheight="16.0px" dataX="375.0" dataY="458.0"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_19" class="inputIOS checkbox firer commentable non-processed unchecked" customid="Input 19"  datasizewidth="16.0px" datasizeheight="16.0px" dataX="375.0" dataY="510.4"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_20" class="inputIOS checkbox firer commentable non-processed unchecked" customid="Input 20"  datasizewidth="16.0px" datasizeheight="16.0px" dataX="375.0" dataY="554.1"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_21" class="inputIOS checkbox firer commentable non-processed unchecked" customid="Input 21"  datasizewidth="16.0px" datasizeheight="16.0px" dataX="375.0" dataY="597.9"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_22" class="inputIOS checkbox firer commentable non-processed unchecked" customid="Input 22"  datasizewidth="16.0px" datasizeheight="16.0px" dataX="375.0" dataY="641.6"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_23" class="inputIOS checkbox firer commentable non-processed unchecked" customid="Input 23"  datasizewidth="16.0px" datasizeheight="16.0px" dataX="375.0" dataY="685.4"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Input_24" class="inputIOS checkbox firer commentable non-processed unchecked" customid="Input 24"  datasizewidth="16.0px" datasizeheight="16.0px" dataX="375.0" dataY="729.1"      tabindex="-1">\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Guardar"   datasizewidth="164.0px" datasizeheight="48.0px" dataX="133.0" dataY="824.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Guardar</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="40.2px" datasizeheight="44.0px" dataX="334.8" dataY="715.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;