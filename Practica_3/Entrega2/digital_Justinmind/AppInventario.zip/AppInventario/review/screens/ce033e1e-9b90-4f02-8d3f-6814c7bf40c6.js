var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705369689725.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-ce033e1e-9b90-4f02-8d3f-6814c7bf40c6" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="BuscarActFij_2"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/ce033e1e-9b90-4f02-8d3f-6814c7bf40c6-1705369689725.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="430.0px" datasizeheight="100.0px" dataX="0.0" dataY="47.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/c70832c3-86a5-4f0f-917c-83e2108000b5.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Input_1" class="text firer commentable non-processed" customid="Input 1"  datasizewidth="257.0px" datasizeheight="45.0px" dataX="19.0" dataY="210.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="05-003-0012"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="257.0px" datasizeheight="45.0px" dataX="19.0" dataY="165.5" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="C&oacute;digo de Activo Fijo"/></div></div>  </div></div></div>\
      <div id="s-Path_128" class="path firer commentable non-processed" customid="Search"   datasizewidth="48.8px" datasizeheight="53.9px" dataX="302.0" dataY="161.1"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="48.76076889038086" height="53.918983459472656" viewBox="302.0 161.08101987838745 48.76076889038086 53.918983459472656" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_128-ce033" d="M322.12298842526366 205.16843178740532 C326.1886238121476 205.16843178740532 329.9985382699863 203.82388226225072 333.16900613388356 201.52709064085542 L344.3683398730887 213.8233998746113 C345.1099000483854 214.60769257108603 346.05598147794603 215.0 347.0788596452301 215.0 C349.20084673000395 215.0 350.760769367218 213.179326387467 350.760769367218 210.88253476607173 C350.760769367218 209.81811365525704 350.42824615155195 208.7817327391988 349.71228858809457 207.99744004272407 L338.5897571355101 195.75721727699712 C340.8909514053647 192.17196563773425 342.2460642456587 187.83046149675303 342.2460642456587 183.12469620013042 C342.2460642456587 170.996494407559 333.19460874572286 161.08101987838745 322.12298842526366 161.08101987838745 C311.07711498797187 161.08101987838745 302.0 170.996494407559 302.0 183.12469620013042 C302.0 195.25305299486232 311.0515428950673 205.16843178740532 322.12298842526366 205.16843178740532 Z M322.12298842526366 199.2863854874891 C314.017581061505 199.2863854874891 307.36957629688277 192.00369711587322 307.36957629688277 183.12469620013042 C307.36957629688277 174.24562842071055 314.017581061505 166.9630676979327 322.12298842526366 166.9630676979327 C330.22865936164095 166.9630676979327 336.87651846771075 174.24562842071055 336.87651846771075 183.12469620013042 C336.87651846771075 192.00369711587322 330.22865936164095 199.2863854874891 322.12298842526366 199.2863854874891 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_128-ce033" fill="#05BE6A" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_3" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="257.0px" datasizeheight="45.0px" dataX="19.0" dataY="280.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Descripci&oacute;n"/></div></div>  </div></div></div>\
      <div id="s-Input_4" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="357.0px" datasizeheight="45.0px" dataX="19.0" dataY="325.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Armario de madera "/></div></div>  </div></div></div>\
      <div id="s-Input_5" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="257.0px" datasizeheight="45.0px" dataX="19.0" dataY="370.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Fecha Adquisici&oacute;n:"/></div></div>  </div></div></div>\
      <div id="s-Input_6" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="357.0px" datasizeheight="45.0px" dataX="19.0" dataY="415.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="2000-12-31"/></div></div>  </div></div></div>\
      <div id="s-Input_7" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="257.0px" datasizeheight="45.0px" dataX="19.0" dataY="460.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Monto:"/></div></div>  </div></div></div>\
      <div id="s-Input_8" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="357.0px" datasizeheight="45.0px" dataX="19.0" dataY="505.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="40.20"/></div></div>  </div></div></div>\
      <div id="s-Input_9" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="257.0px" datasizeheight="45.0px" dataX="19.0" dataY="550.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Situaci&oacute;n"/></div></div>  </div></div></div>\
      <div id="s-Input_10" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="357.0px" datasizeheight="45.0px" dataX="19.0" dataY="595.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Operativo"/></div></div>  </div></div></div>\
      <div id="s-Input_11" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="257.0px" datasizeheight="45.0px" dataX="19.0" dataY="640.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Centro Costo"/></div></div>  </div></div></div>\
      <div id="s-Input_12" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="357.0px" datasizeheight="45.0px" dataX="19.0" dataY="685.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="EP. Ing. de Sistemas"/></div></div>  </div></div></div>\
      <div id="s-Input_13" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="297.0px" datasizeheight="45.0px" dataX="19.0" dataY="730.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Centro de Responsabilidad"/></div></div>  </div></div></div>\
      <div id="s-Input_14" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="357.0px" datasizeheight="45.0px" dataX="19.0" dataY="775.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="EP. Ing. de Sistemas - Direcci&oacute;n"/></div></div>  </div></div></div>\
      <div id="s-Input_15" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="257.0px" datasizeheight="45.0px" dataX="19.0" dataY="820.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Empleado Responsable"/></div></div>  </div></div></div>\
      <div id="s-Input_16" class="text firer commentable non-processed" customid="Input 2"  datasizewidth="357.0px" datasizeheight="45.0px" dataX="19.0" dataY="865.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Calderon Arce Guillermo"/></div></div>  </div></div></div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="100.0px" datasizeheight="80.0px" dataX="0.0" dataY="57.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;