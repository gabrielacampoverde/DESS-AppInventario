var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705369689725.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-ba4978d3-a9de-46e3-8d65-71db29f005de" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="ReporteInv_3"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/ba4978d3-a9de-46e3-8d65-71db29f005de-1705369689725.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="430.0px" datasizeheight="100.0px" dataX="0.0" dataY="59.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b277bb93-79c5-4f6f-bb30-be9624543377.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext manualfit firer commentable non-processed" customid="Reporte de Inventario"   datasizewidth="268.0px" datasizeheight="38.0px" dataX="65.0" dataY="95.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Reporte de Inventario</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="379.0px" datasizeheight="290.0px" datasizewidthpx="379.0" datasizeheightpx="290.0" dataX="25.5" dataY="232.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="richtext manualfit firer ie-background commentable non-processed" customid="00994 - E.P. Ing. de Sist"   datasizewidth="345.0px" datasizeheight="84.0px" dataX="43.0" dataY="257.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">00994 - E.P. Ing. de Sistemas - Direcci&oacute;n</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_1" class="path firer commentable non-processed" customid="Line 1"   datasizewidth="347.0px" datasizeheight="3.3px" dataX="42.0" dataY="332.0"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="346.00360107421875" height="3.249993324279785" viewBox="41.99818843603134 332.00000327825546 346.00360107421875 3.249993324279785" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_1-ba497" d="M42.5 333.0 L387.5 334.25 "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_1-ba497" fill="#000000" fill-opacity="1.0" stroke-width="1.0" stroke="#000000" stroke-linecap="butt"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_3" class="path firer commentable non-processed" customid="Minus"   datasizewidth="20.7px" datasizeheight="13.0px" dataX="42.0" dataY="358.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="21.712848663330078" height="14.003900527954102" viewBox="41.99999999999997 358.5 21.712848663330078 14.003900527954102" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_3-ba497" d="M43.89819183935194 372.0038995742798 L61.814757800546296 372.0038995742798 C62.569483567238606 372.0038995742798 63.212849617004366 369.0953951758203 63.212849617004366 365.5022746926256 C63.212849617004366 361.9662571221248 62.569483567238606 359.0 61.814757800546296 359.0 L43.89819183935194 359.0 C43.16815897285389 359.0 42.49999999999997 361.9662571221248 42.49999999999997 365.5022746926256 C42.49999999999997 369.0953951758203 43.16815897285389 372.0038995742798 43.89819183935194 372.0038995742798 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_3-ba497" fill="#099957" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Path_2" class="path firer commentable non-processed" customid="Minus"   datasizewidth="20.7px" datasizeheight="13.0px" dataX="42.0" dataY="431.5"  >\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg xmlns="http://www.w3.org/2000/svg" width="21.712848663330078" height="14.003900527954102" viewBox="41.99999999999997 431.5 21.712848663330078 14.003900527954102" preserveAspectRatio="none">\
          	  <g>\
          	    <defs>\
          	      <path id="s-Path_2-ba497" d="M43.89819183935194 445.0038995742798 L61.814757800546296 445.0038995742798 C62.569483567238606 445.0038995742798 63.212849617004366 442.0953951758203 63.212849617004366 438.5022746926256 C63.212849617004366 434.9662571221248 62.569483567238606 432.0 61.814757800546296 432.0 L43.89819183935194 432.0 C43.16815897285389 432.0 42.49999999999997 434.9662571221248 42.49999999999997 438.5022746926256 C42.49999999999997 442.0953951758203 43.16815897285389 445.0038995742798 43.89819183935194 445.0038995742798 Z "></path>\
          	    </defs>\
          	    <g style="mix-blend-mode:normal">\
          	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#s-Path_2-ba497" fill="#099957" fill-opacity="1.0"></use>\
          	    </g>\
          	  </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Empleado Responsable:1221"   datasizewidth="255.5px" datasizeheight="50.0px" dataX="92.0" dataY="357.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Empleado Responsable:<br /></span><span id="rtr-s-Paragraph_2_1">1221 - Fernando Paredes</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_4" class="richtext autofit firer ie-background commentable non-processed" customid="Inventariador:3280 - Stef"   datasizewidth="222.6px" datasizeheight="50.0px" dataX="87.2" dataY="426.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_4_0">Inventariador:<br /></span><span id="rtr-s-Paragraph_4_1">3280 - Stefany Alvarez</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer commentable non-processed" customid="Enviar Reporte"   datasizewidth="171.2px" datasizeheight="48.0px" dataX="43.8" dataY="604.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Enviar Reporte</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="Salir"   datasizewidth="151.0px" datasizeheight="51.0px" dataX="234.3" dataY="602.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Salir</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="171.2px" datasizeheight="49.5px" dataX="43.8" dataY="602.5"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="153.2px" datasizeheight="48.0px" dataX="233.2" dataY="603.3"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;