var content='<div class="ui-page " deviceName="iphone15promax" deviceType="mobile" deviceWidth="430" deviceHeight="932">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS iphone-device canvas firer commentable non-processed" alignment="left" name="Template 1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1705369689725.css" />\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-39e848aa-f868-48eb-9927-78c1d09bb6cf" class="screen growth-vertical devMobile devIOS iphone-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="ReporteInv_1"width="430" height="932">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/39e848aa-f868-48eb-9927-78c1d09bb6cf-1705369689725.css" />\
      <div class="freeLayout">\
      <div id="s-Image" class="image firer ie-background commentable non-processed" customid="Image"   datasizewidth="430.0px" datasizeheight="100.0px" dataX="0.0" dataY="59.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b277bb93-79c5-4f6f-bb30-be9624543377.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="richtext manualfit firer commentable non-processed" customid="Reporte de Inventario"   datasizewidth="268.0px" datasizeheight="38.0px" dataX="65.0" dataY="95.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Reporte de Inventario</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Category_1" class="dropdown firer click commentable non-processed" customid="Category 1"    datasizewidth="418.0px" datasizeheight="95.0px" dataX="6.0" dataY="294.0"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">E.P. Ing. de Sistemas</div></div></div></div></div><select id="s-Category_1-options" class="s-39e848aa-f868-48eb-9927-78c1d09bb6cf dropdown-options" ><option  class="option">E.P. Publicidad</option>\
      <option selected="selected" class="option">E.P. Ing. de Sistemas</option>\
      <option  class="option">E.P. Ing. Mec&aacute;nica</option>\
      <option  class="option">E.P. Biotecnolog&iacute;a</option>\
      <option  class="option">E.P. Enfermeria</option>\
      <option  class="option">E.P. Medicina Humana</option>\
      <option  class="option">E.P.Farmacia y Bioqu&iacute;mica</option></select></div>\
      <div id="s-Paragraph_2" class="richtext autofit firer ie-background commentable non-processed" customid="Centro de Costo"   datasizewidth="233.3px" datasizeheight="34.0px" dataX="104.0" dataY="223.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">Centro de Costo</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;