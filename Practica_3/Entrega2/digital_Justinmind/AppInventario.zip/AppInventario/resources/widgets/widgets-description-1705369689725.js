	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["s-Image", "e12ef55f-c629-4883-b3e6-c661ea1ba5eb"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "e12ef55f-c629-4883-b3e6-c661ea1ba5eb"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "e12ef55f-c629-4883-b3e6-c661ea1ba5eb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "e12ef55f-c629-4883-b3e6-c661ea1ba5eb"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image_2", "e12ef55f-c629-4883-b3e6-c661ea1ba5eb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_2", "e12ef55f-c629-4883-b3e6-c661ea1ba5eb"]] = ["Image", "s-Image_2"]; 

	widgets.descriptionMap[["s-Image_3", "e12ef55f-c629-4883-b3e6-c661ea1ba5eb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_3", "e12ef55f-c629-4883-b3e6-c661ea1ba5eb"]] = ["Image", "s-Image_3"]; 

	widgets.descriptionMap[["s-Image_4", "e12ef55f-c629-4883-b3e6-c661ea1ba5eb"]] = ""; 

			widgets.rootWidgetMap[["s-Image_4", "e12ef55f-c629-4883-b3e6-c661ea1ba5eb"]] = ["Image", "s-Image_4"]; 

	widgets.descriptionMap[["s-Image", "b9a095cb-7108-4a70-ab1b-6d4e201a2809"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "b9a095cb-7108-4a70-ab1b-6d4e201a2809"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "3aa2da95-2daf-49f8-b2ca-ebf352667170"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "3aa2da95-2daf-49f8-b2ca-ebf352667170"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "39e848aa-f868-48eb-9927-78c1d09bb6cf"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "39e848aa-f868-48eb-9927-78c1d09bb6cf"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "d6aece7f-8bf9-4764-8114-fdd8a36a1de0"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "d6aece7f-8bf9-4764-8114-fdd8a36a1de0"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "b8ef45a4-1ea4-4f13-b2e6-e719bf121ec8"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "b8ef45a4-1ea4-4f13-b2e6-e719bf121ec8"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_29", "b8ef45a4-1ea4-4f13-b2e6-e719bf121ec8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_29", "b8ef45a4-1ea4-4f13-b2e6-e719bf121ec8"]] = ["Plus", "s-Path_29"]; 

	widgets.descriptionMap[["s-Path_26", "b8ef45a4-1ea4-4f13-b2e6-e719bf121ec8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_26", "b8ef45a4-1ea4-4f13-b2e6-e719bf121ec8"]] = ["Minus", "s-Path_26"]; 

	widgets.descriptionMap[["s-Path_2", "b8ef45a4-1ea4-4f13-b2e6-e719bf121ec8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "b8ef45a4-1ea4-4f13-b2e6-e719bf121ec8"]] = ["Plus", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "b8ef45a4-1ea4-4f13-b2e6-e719bf121ec8"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "b8ef45a4-1ea4-4f13-b2e6-e719bf121ec8"]] = ["Minus", "s-Path_3"]; 

	widgets.descriptionMap[["s-Image", "e0f70fff-f111-40a0-994c-f2b4367d6b23"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "e0f70fff-f111-40a0-994c-f2b4367d6b23"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "e0f70fff-f111-40a0-994c-f2b4367d6b23"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "e0f70fff-f111-40a0-994c-f2b4367d6b23"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image", "eca306c7-e78e-43bc-a96a-733ce12f7c8c"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "eca306c7-e78e-43bc-a96a-733ce12f7c8c"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_37", "eca306c7-e78e-43bc-a96a-733ce12f7c8c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_37", "eca306c7-e78e-43bc-a96a-733ce12f7c8c"]] = ["Multiply", "s-Path_37"]; 

	widgets.descriptionMap[["s-Image", "ce033e1e-9b90-4f02-8d3f-6814c7bf40c6"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "ce033e1e-9b90-4f02-8d3f-6814c7bf40c6"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_128", "ce033e1e-9b90-4f02-8d3f-6814c7bf40c6"]] = ""; 

			widgets.rootWidgetMap[["s-Path_128", "ce033e1e-9b90-4f02-8d3f-6814c7bf40c6"]] = ["Search", "s-Path_128"]; 

	widgets.descriptionMap[["s-Image", "6ff82a5b-5571-4f51-bc71-8ac900a5b81a"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "6ff82a5b-5571-4f51-bc71-8ac900a5b81a"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_128", "6ff82a5b-5571-4f51-bc71-8ac900a5b81a"]] = ""; 

			widgets.rootWidgetMap[["s-Path_128", "6ff82a5b-5571-4f51-bc71-8ac900a5b81a"]] = ["Search", "s-Path_128"]; 

	widgets.descriptionMap[["s-Image", "ba4978d3-a9de-46e3-8d65-71db29f005de"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "ba4978d3-a9de-46e3-8d65-71db29f005de"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_3", "ba4978d3-a9de-46e3-8d65-71db29f005de"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "ba4978d3-a9de-46e3-8d65-71db29f005de"]] = ["Minus", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_2", "ba4978d3-a9de-46e3-8d65-71db29f005de"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "ba4978d3-a9de-46e3-8d65-71db29f005de"]] = ["Minus", "s-Path_2"]; 

	widgets.descriptionMap[["s-Image", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_15", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Chevron down", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Chevron down", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_17", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Chevron down", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_18", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Chevron down", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_19", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Chevron down", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_20", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Chevron down", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_21", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Chevron down", "s-Path_21"]; 

	widgets.descriptionMap[["s-Path_22", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Chevron down", "s-Path_22"]; 

	widgets.descriptionMap[["s-Path_23", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_23", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Chevron down", "s-Path_23"]; 

	widgets.descriptionMap[["s-Path_24", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_24", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Chevron down", "s-Path_24"]; 

	widgets.descriptionMap[["s-Path_25", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_25", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Chevron down", "s-Path_25"]; 

	widgets.descriptionMap[["s-Path_26", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ""; 

			widgets.rootWidgetMap[["s-Path_26", "6c66ef97-f8a3-4a33-951c-2895a142fd0e"]] = ["Chevron down", "s-Path_26"]; 

	widgets.descriptionMap[["s-Image", "c151f23a-d746-4c3d-a6a2-e8285ab9e78a"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "c151f23a-d746-4c3d-a6a2-e8285ab9e78a"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_63", "c151f23a-d746-4c3d-a6a2-e8285ab9e78a"]] = ""; 

			widgets.rootWidgetMap[["s-Path_63", "c151f23a-d746-4c3d-a6a2-e8285ab9e78a"]] = ["Person", "s-Path_63"]; 

	widgets.descriptionMap[["s-Image", "53ec5e95-908b-4339-8524-af132177c246"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "53ec5e95-908b-4339-8524-af132177c246"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "42fd667a-a210-491e-b69f-d67a7074e672"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "42fd667a-a210-491e-b69f-d67a7074e672"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_2", "42fd667a-a210-491e-b69f-d67a7074e672"]] = ""; 

			widgets.rootWidgetMap[["s-Path_2", "42fd667a-a210-491e-b69f-d67a7074e672"]] = ["Plus", "s-Path_2"]; 

	widgets.descriptionMap[["s-Path_3", "42fd667a-a210-491e-b69f-d67a7074e672"]] = ""; 

			widgets.rootWidgetMap[["s-Path_3", "42fd667a-a210-491e-b69f-d67a7074e672"]] = ["Minus", "s-Path_3"]; 

	widgets.descriptionMap[["s-Path_5", "42fd667a-a210-491e-b69f-d67a7074e672"]] = ""; 

			widgets.rootWidgetMap[["s-Path_5", "42fd667a-a210-491e-b69f-d67a7074e672"]] = ["Plus", "s-Path_5"]; 

	widgets.descriptionMap[["s-Path_6", "42fd667a-a210-491e-b69f-d67a7074e672"]] = ""; 

			widgets.rootWidgetMap[["s-Path_6", "42fd667a-a210-491e-b69f-d67a7074e672"]] = ["Minus", "s-Path_6"]; 

	widgets.descriptionMap[["s-Image", "97b5c424-f339-426c-bece-f1889b1c8fdd"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "97b5c424-f339-426c-bece-f1889b1c8fdd"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image_1", "97b5c424-f339-426c-bece-f1889b1c8fdd"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "97b5c424-f339-426c-bece-f1889b1c8fdd"]] = ["Image", "s-Image_1"]; 

	widgets.descriptionMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "d12245cc-1680-458d-89dd-4f0d7fb22724"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "e20bf34b-c806-4bd2-8a7a-5038932529f2"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "e20bf34b-c806-4bd2-8a7a-5038932529f2"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Image", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ""; 

			widgets.rootWidgetMap[["s-Image", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ["Image", "s-Image"]; 

	widgets.descriptionMap[["s-Path_15", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_15", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ["Chevron down", "s-Path_15"]; 

	widgets.descriptionMap[["s-Path_16", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_16", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ["Chevron down", "s-Path_16"]; 

	widgets.descriptionMap[["s-Path_17", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_17", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ["Chevron down", "s-Path_17"]; 

	widgets.descriptionMap[["s-Path_18", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_18", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ["Chevron down", "s-Path_18"]; 

	widgets.descriptionMap[["s-Path_19", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_19", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ["Chevron down", "s-Path_19"]; 

	widgets.descriptionMap[["s-Path_20", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_20", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ["Chevron down", "s-Path_20"]; 

	widgets.descriptionMap[["s-Path_21", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_21", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ["Chevron down", "s-Path_21"]; 

	widgets.descriptionMap[["s-Path_22", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_22", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ["Chevron down", "s-Path_22"]; 

	widgets.descriptionMap[["s-Path_23", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_23", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ["Chevron down", "s-Path_23"]; 

	widgets.descriptionMap[["s-Path_26", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ""; 

			widgets.rootWidgetMap[["s-Path_26", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ["Chevron down", "s-Path_26"]; 

	widgets.descriptionMap[["s-Image_1", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ""; 

			widgets.rootWidgetMap[["s-Image_1", "8adf3871-fea2-43f0-b763-dfadebf3f47c"]] = ["Image", "s-Image_1"]; 

	